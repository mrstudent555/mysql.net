<!DOCTYPE HTML><html>
	<head>
		<title>Next AutoIndex Installation Wizard</title>
		<style>
		body{max-width:480px;margin:0px auto;padding:0px;background:#f7f7f7;color:#555;font-family:Open Sans,Arial,Ubuntu Sans;font-size:13px}
		.logo{text-align: center;
background: #FFF;
border-bottom: 1px solid #EFEFEF;
padding: 3px 1px;}
.l{background:white;padding:4px;margin-bottom:1px}
.ttl {
    padding: 6px 10px;
    background: #28B8F7;
    color: #FFF;font-weight: bold;border-bottom: 1px solid rgba(0, 174, 255, 1);
}
#foot{background: none repeat scroll 0% 0% #333;
color: #999;
text-align: center;
padding: 8px;
margin-top: 5px;
border-bottom: 3px solid #28B8F7;}
input[type=text]{padding: 8px;
margin: 1px;
border: 1px solid rgba(224, 224, 224, 1);
background: rgba(255, 255, 255, 1);}
input[type=text]:focus{border:1px solid #28B8F7}
input[type=submit]{display: block;
text-align: center;
width: 96%;
padding: 7px;
background: none repeat scroll 0% 0% #28B8F7;
border: 1px solid #28A7F7;
color: #FFF;
font-size: 15px;
font-weight: bold;
margin: 0px 6px;}
tip{display:block;font-size:11px;color:grey}
		</style>
		<link rel="shortcut icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAG5klEQVRIiZ2Wa2wU1xmGJ4VUyMYGL+t4vbazu7OmMVDSBlXQKipRlaoRCbmUpFQFJKBJVSWkUaWkIpVIhNQGokAgCEigmFQlLWqcYDBmd2bWxsZroCYQI9eYgjGXEINMbGPj3ZkzF+88/bE1Zs2lhld6f8yf88x3vu+850jSKOWt0v2yYswLq+KdsGr8MxgVWjAiYrJmVIY0c0NYSS7xVw+UjXa9/6tgNPFYSBF/l1Xjm7AmuO6YoDR2w7cmkFWhy6oZlSPG8/cM9G7vzimpNTbJmnAzgKNwqSp4sM78vKC2X767KrWBsqBiHA6rdwfMsCqQFeNCIG4+NSrolGp9hqyK8+HY3YFkzaRof4r8BpjUCJ5G8MYhUGOLyZHk0jtCiyoHvlMaM76628p8dS6+OMzefYlXP9BYv2I7m5Z/yIp3K3kkcpWgZtuFTdZt+q51ZYf26E0jB+a2fdQEJarAExvk2fJmlPnLSJZNhQc84MkBz3jIHsPfXnuP/DiENKPH02xNvYnr/5e5uVQZfaVFimBajeDjyy561V6YmA2ePCgpgpLitPNyaPz5UvwNLrJmIsfEUbni6oTr0HDVwKNhxbg+vUE17dtBA6ogpAriXQJSJoOA88kOmJALhYXDYE8uDfNexH/ARY6ZhFVBKGq8fh0c0sQnpf8DFkQEU2sEU2oEhdERwFqHwjrwRC02nk5DU5YJpo4LuGvXQlbWMDxvPLt+8zb5cQhr5tBZP1WwoytbyqrS/SHV6AmpgpAm2HDG4WzC5UzC5Y+tNnkRgbfGxRuHGXt7eWzLcd5q6iXl2KRMg9aO86w60Ma2I6fpSQzgrl4NOTng88GkXFas3oU3TkYBvt36HElWjefDmiA/Ilh/xuFGpYANnfBu40X++ts/czkwmas/ewK77yqum6Lz0iXm7D1B9mfnya04yzvxU9ikGNy6FSbmMDB5Cj+q6qK4dnDEYCbXSbImVgXUdN86Em4GeADoaaiHR2fCuPsxfQXozV9iAa5t8cWpsxR/dobi3efI+/wCz+07SbK/Fxtgy0bKf/8+3gPcNCNyVMSkkGJ8WqQItpzLrDYJdEYiOMEg5OVhZWXRt3EjJiBME8ey6L7SxaJIKzkVZ/FVnOGjQ204egJSFq0Jlyl1DiWqeTNYNY5Ik/YI7ZnDZgZUAF8d/RLr4eng8ZDKy6N/7lwMw0DYNkIIhDBxLJOLnZ3sPHYapaWdgb5eGLS4qgt+0WTijd4MDauCUK3ZIk3aI2rmNQ2DU8DXHecQs2amJzQnh6THw0Bzc7paITLs2BbYAmwLXIeWHsEP6wQ5+wTybZIuVGu2SIGoXhlQBTsvDm91d6Qasr8Nj0zHWTif3vJyhOsiTPMmsBACYdukgONdCV5ptlh8zGbuIZMiRVCspFMuY6tjxlEppJkbhgJjyVGLFScdXjvYzRtb9rNMvcCv/+3QokPKvjXUBITrcm3NGk5+WI6eSv+844LSNcgP6kyKRyaiIuqlsCKWhLV0EhVEBd6IQYFqMf4g5NW4TN/zDR39KVzbyoQ6DiaQbG+nb9EizDHfousfO9MTfYNqrqTIjwhk9cbjpJdL3irzoZAmjBu3o2h/ih9XdtC0eDZXFoynq3YlFmBaNoOmYBAXQwj6Nm9mYPJkBseOxZoxg4sXviY1Amyl4FdHLPIjwz0OVCcXSpIk3RfShDYEDsUsSmptGl96HH4iwSaJa1sleg+txLQEly2HtrZzXHv6KcysLPB6YUIunX/ZRh+3VsJxeeW4jS8qkDXjSkFl4oF0VketF0pVg7Am8O+Hn1a00TcnG/dlCXvbGJxt92H9QWLD9p083ArxNVth3P3g98O4cfS8+jsuG+ZtsGm19KcoUQXBSHLd8J24sn5s4IBZGVYFgRqHaZFeYi8/C09I8LQEz0gwW2L+R1E8h6F1wUswIRvyculbvpzu/v47QgE+vjCIf59oD+zqLsy4jz1fGCVhRe8MxWzkmEnbguk0Ln2citdf5MQvv8+b67fjq4fvVfVyLSDDxPG0r1rLad2h34V+G/pGuN+GjoTLB+0OsiYGfQf0Obd8hBQf1J+UNcssUxIsLtcI1liUKQnKlGvk10MoZvGQovOnN8tZ9t4+ph2GWXGHWfWCmbfwrPr09ZofMfDVirfu+O6S1eTSsCIs//40KBizCdY4GY86bxwKGiCgmZQo4o5OZ4S5/o7QIT1Ya70Qihld9/y0HY7HlD8m3h4VdEgF9YnvhmKi6V6hsir+U9ygP3lX0CF5or254WjyjbBinhg90LgsK8b7xdVG0T1BM6rf0ZVdHNXnyFpynawIrVQ1joQUsyWkmC1hzTgWVkWdrOnlgWqxMBhJ+kaz5n8BU3N8hNkFbi8AAAAASUVORK5CYII=" type="image/x-png"/>
	</head>
	<body>
	<div class="logo"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAAsCAYAAAAQAeYrAAAUL0lEQVR4nO1deXAc1Z1uNoGwS7IIbNbYunp0zGEWVvwREhYCvdNtVjMVwLVblSy1HArZOCTAlkIIKYoiNkdVCImjrZBFK4ktEQNLsBeEbWl6RgaPfEAwmAiwicCW3BhjlwuwR1iefj2Xvv1jutuvXx9zSLapzXxVr/DMO3+vf9/7Ha9HcFwNNdRQQw011FBDDTXUUEMN84K2+MxFfln9l/YYedAvpwdbh7Xn2zZqQ+0x9ZmgrK5uH9G+H9x47PJFaw6fc7rXWkMNnyv4N6r17THtzvaYOhaMq58G4wRmSRCEEtTnOEFQJun2GNnlHyE/D8jHLznd66+hhtOLVckv+l8i9wZkogTjBKE4Q5gySkAmx/yy+pv6HccWnG5xaqjhlMP3PGlu3aAN2axNlcU/qu5sk2eE0y1XDTWcMvjj5Bv+TWSyGgvkWmSCoKymW8e0f3eaEzxfB54X3NYEnufB84JRnPp6lI5yxtHrO9h+zHeupeKN7ptczvVNrfJs0zvBc717Ba53r8D17+mw1PWM15l1vXsFxz5epWe8znXO/skurm9qFTcw1W2bl0b/ng7n8Sd463hljsG2c5WFGt8NpeQ3wO4juy/sGsrBReuPdwZi6idzIU1IVtE2mkXTZqB+DFiypViaNgMBWUMwNvMAOy94XkBLC9DSMui0LrS0rNLrgZYWuPR1Lj5fkmrbbanj+S6qjmf6DnIcx8HnS3qO77CmsjCgpM4YUMD1T3a5tumbWnXGgIIzBhRwA0rSUte7VzDqzhhQ4NTHq9iUoneC5/qVIce2A0rSUYkGlKRje/qA0NfjKic1hk1GD1m4fkXxOohKym+gf08HM65VB/sVxTJnKbRsIleGYuSTwBxI1PwysGQrcEk8jX96ahfu7onj/ofX4r5H1+Pbv3sH7ZtyCMYI2jdn7qHnZshgI9N8EYnjOA4+n0LVKdT3Ser7FHi+zvb9fBGpf7LLVXlonCoi9e/pMIjt2YclQwVEciVTlUSilHvcybqWTSSO47h+ZdC6N7rFY+YvaZGWrCFNAVmdDFYRE4XiBC2yhiWxDJY9O4X+H/0KytX/COL3A031QMMioGERtJZm3PPLjWhMziI4rOaXvJ6+1pjfRgae76bXN69EcpjLa/6TQiRGAV1dlVNBpJ7xOvrULa24lPtVIZFs/ZkxqiGSTqYhdusqIlLPeB19kHD9ypDjd55QlLNb4trQUrk6EjWNEFy6pYBHtnyI1BXfAOrOAeoXA02NAM8DPl/xvwvPxfrv/hSNW4CgrKE9oR7wbdYCHOdCBtrtqoBI3sKa4w1ZrI/PN059HvfotwouBC0bvRO8XfGUHse21RCp0jasog8oKa5/sovr3StwfZPLuX5lnKmvbB2O4zuTsRSRTsRSk10s+VlrUZEl4TiOG5jqZuW0rLlUXOZPkHtDo9WRqHGE4NptBO9Na0A+i8KGF4HmZqChwX5qX7gQsRtuR9MYEEhoCMoEIZlsumjtu2e5WhWeX85xJ4FIPM/D50u5zOm66fNCJMaNMB+UU/B/KohEEcVVYVgy0WutkEi2eSohEg27xbCEBBUTyUFORwvrhMb16SWBWPoATZB2maBNJvCKlUJxguYRgq+9RLB/mgA5gkwmAw1A7okngAsuKBKKIdKG7/ykSKS4Zo7VNpy+zpVIxViloyLXzudLWgpl2Sz9mDHd4jPXPtUQiX34FkVwiB9ONpF6xuvKs4yTy63tJpeXPYeLe2bGNtUSieM4rk/pocazJAJscw0oSbO4ycnI4jSuI3wx7c5QokiMdpmgYZjgbxMEHZsI+JEioUIUeYJxgrZNOTSP5tASI1j/IQHyRRLNaipmtTQKAPKPPAIsWFB06VpbTSL9192PoWErrHdMI9pGzzinaDmGyiaSvaxyk9+SeChaI+eUsNF+rkSikwz9ikK7E1y/YncpTzaR2HqPk9v1hK6SSKbMVotYIZEYgrus18Eiuj87NvFAHxqO6Nt5pm9E3bo0QdAaK1qgX72fw7ufFfBBehbPfpjHxaMaFg8TNMlZNIwBTWNAx8YULnr2IHrfV4G8hmwmg9THh7H+jd34jy27sGX3HqgZFfmHHgIWLgQaGwEfDzQ34IePbUbD2AkihRIE/hE1NXzdilsY8ox7kYMWo1oiucRl3U5tzT5zJhKtNFPdNovABuL/D4nk5j5VRSSPuasiEuMx6Ov1TjK0xWaWBuJqKqC7aWs+yIPFhkMFXL8jj2/vzOKmx1/Bi9+6A3uDHZi47yFkC3nkclmo00fQk3wL/HN7cOHaffi7dRNY/8cJZAsF5B97DKivBxYtxKHLr8ZXh4+idTRncxUf/clvfsXGKWhpGaySSKssxSXmcSQrlfZ27DMXIrEP3YgzqLsb2x3GySYSe4cyMOV8kNjuWig3tFIiFbOEzrFIxRbJsj8puoohwyDXN7XKLG53WpSrWO4Bw7WPqDcE9azbsq0atIKNR0gDmPrgQxy7q7sY83z5bJCvX4bCwQPI5PPIZTPYryi46oU/Yck6Be3PT+Fv1iq4deQdzKSOIAsg+9RTwMK/Ru9dPVi8DQjJqpVICYIfP7Au5hTwu6WeaTmqTDZ02wh04rOz/8zNkUiUy2BeJvZNrWIvQS2B/KlINlgDdueMpVcKu1IicZzjyV8VkayXpRbLUTYRzLHYQ6WMfeE4jgvE0g8G4gSLNxI8MpF1JNHkW+8gfe03i/FOQz0+a2rCZ2Nj0AAQQpDLZnFw/we4Zmg3Fq1T0Pb8Pixcq+B2+R2kj3yMTC6HWcxi3/8O42trD8LnYI2CcYI7Htm4w5FIPF/nZDloOSolkj5miiaELfFAvVZk6VstkRgXztvtoKwCHUOxaWOamMxpbKK8rJ01JuhXBi1kZtPCbPBdDZE4zvESuGwiObyFwVqZionEprvZ+MvNWrfH0k82jhB0v5VFhrFGBMC+PVNQhauLcU5rK7S6Ohy9//4iiTQNhBBoWgbazDSeeeVtXLpuAk1r90J8YTe2vf0nZEka+QxBLqvhpl1AfTxrt0Z6ue2XsV1OROI4ZzLRcpTM2rEXsqzLWHz/zkYupz2rmkiMMnoSiVZUpzunASVpu0NhXUKzfzlWyz6HcQo7f08pbHEt9nsmOivmZVUYMs3hQtZmMWz1dNZuQElaD6UTSSCLjCy5nK4oml/Qng8mVLw1bWVRBsDUR4cwfdPNRRK1tKCweDGOXnUV0h9/DK1QACHELJlsFur0Ubw5sQfD4xN4f+8kMsdnUMhqQJbg8T0EjcPu6fSQTLCiR37PjUgcZ7/3YepKJRtAte1g6kwFdLBKXRyDqonEvq9le6iMMtInqIvfbnnAbpeF5RCJ42yK5KGwrnc1rpalgsxbVa8IsZa6xNpse8y82WE9yJj9czqwmoe0oaUJgt2fzZokmgWwP3UMR1asAM4/vxgXLV6MYxdcgM9eesl06diiaRnMZjNAliCfzQA5DdMqwZ07CRZtJPDLHr9nkgm+9+v4+15E4jidBDqZmO/LJxIbc/E8T43DWiVb4qEqIrEugpub4eHvO13ieimRiXKJxHEc1z/Z5fW+ndPdy7wQSZ+7GiIVX6Z1PkTKJpIt/vN+n9D2/No2qk83jRDcvztrIdKBP7wG1F8InH8u0MIDl16CI3fdBZLPg2SzjkQyi6ahAGBfOo9bXycIJjRcPFq0SPyIO5E617z7RybT5rg5xuUs8x1vy9QxxWxrnaOLGd4gpes6LPUuF7029O4VzMSCm5/NtnO6Se/dK3B9So9uwYaM9Ln33BO855gsesbruIGpbtvlpce7gI6FyeqVtYa+yeU2JWb70uOXemXHbW1GMfobPxlx3XdmD1kiBWV1tV8maIkR3Lsriz8cKWD3sVlselvBG7fcjjdW/Ahj62TIO97FgWNpZHMeJFJVkEwGGQDHX9mOWOxVbP20gAPqLN4/Noun9+chbdHQOOJimWSyyXNTaqjh8wq/rK0IxotulxHDXJwgWLopg9CWAgLbgUWvAF/dAXx0PIu8proSSQNAcjmkenuRamrC4aeesmUBD5NZfOu1DJpZy5Qg8A+T5073ftRQQ1UIxdSvB2RVNV/VkYuvCfllAt9oHr5NeYTX7MQPnt2BmeMZZJ3cunweGoCZiQkcufFGpM89F4XWFux7bSc0+7UU3kwVwI8U57EkHGLHf1qtHBFJ6lkmCO5xwmmGIAh1UUkaj0pSZT+1+DOHIAh1kXDY800TL3SGw12d4XDXPC7JGYvWHD6nTdZ2s65W+2gOgYSKp++5DZr4JRy79Ys4lPxZ0epkciCEIK8RZAGox9M4uno1UsEgsgsWAAsWYPqWW7B/Ju1AIyA3C9z2ZgaNwwR+4xWhGNFah4/9fbVyREQx2SlJwjxuzbwiKoqDEVEcEgTBO545SegUBP7zctBERLHEe2snsEwQOqKi6Hw/VgY6w+GVneHwymr7V4TWmPYLmkihuIolSeDhn68GLueA75yB/JNn4+hjZ+Dj7Q8gVyj+XOJQtgDl1dcxHemEumBB8X26xkbkA35Mjm3DjCONTpDp0fdyposXiJE3uEHl7Gpl+LwTKSKKyVNyMrrglCpUCZxKq3xK5fbJmUuCspo2rVEii6Xycey9IQSEOWR//ZfIPPVlZNacjeO/4LDtvx/G7buBm3cVsP/7P8TsOX9VfLu7sQlYtAgHfvs4DuU8WKQjnZvFNVsy4GMq/DH1DssGCAJvnKL0RnRKkqBvThfd3iCSWz3dNxIOd7OWwSBhJBzu7pQkQRCEumWC0GG4Fk59yh1/mSB0RCVpPBIOdztZBbe5jM+d4fDKTkHgGXmXu8pZdGfMuk5B4KOiOBgVxUFDNmNep/Hd9p5dszkPc4Cxnw3ZjLqoJKFTkgR6LzoFgTeUnpWVHs9YG9XeJr+5Nyd0YSU7HtvXGJP+XJUFD4yk/9MgUutoHpetP4jn7v43aMvPxuxdX8DsD/4C+XvOAq7jsHbFP+MLo8CN21KY7VwG1C8p/oivoR6HH3gQ+48X09+lkCkA127XwI+Qd5qGp8+zCBsOrzTcoYgk9XBcMQ6KiKLSGQ6vjErSeFQUzYuxiCgm9fpkZzi8MiKKiqWe7ltUqhS9cVFJQmc4vFJvt7xTkoSIKCYjojhkzBcRRdc7I6/xI5LUExXFVFSSxg1ZLLIWlWucnkuX3ZBpKCqKKUMZI+FwtyFnVBRTtKJEJKknKknj+h4k9b3sioiiopfkMkHo0MmViorioLE+Q3Gc9t4mb3FNg/p8oJWdtTi0txARxWRUkmDIpn+3PCqKqYgk9Rhrod0/ejx6bW7yG89Bn2vcrZ7WIf15m5ew+rMv2wU10bRt+rzWl7S3Q3oCoH5sFqsfeAC4ggP+gUPumjOBKzhMX3Mebn4igYWvADc/vh1Znw+48AKgpRlHBp/A0dnZ0gzSsfr9HPgRovllciW7HoMM5kmmP3j6NLUoa1FwU9E7BYGPShKMk4buy3HFmIUmWlSSQAe1xslpKJduVRxdknLG93I9zVNal8VYO72eiCgqRn/LyVkkiSk3vWZ2P2mFiorioMXS6wpq/JveezeZ3cbyIpJLvWKxOjrxndqzazMOFWNN7HMwDhynelaHdDm6jEPUTfaS4DeTq0MjJB2MEzRsBl7ovhHj/3oZbu3bgN+uug/P/HgFvvk/bxb/StAW4Gf3/Q74yplILb0Y8pr1GD2SxzszwNvTBc/y4sE8vrszg5aNKpq2EUfXgT5RjQ2LStK46b7ppzh90rHZHeMB0ptN1S1nFdDyMCVJYINcNyKVM35JIjnMRROC7d8pCLzeb5CRo2jZWPfITqSU4caye8TuvRuWCUKHIWe1RHI6oPQMJ5za62sz3/igld7pOdByl9Ih/QAbj4hikt2/iuF7RbszFCNoG83i+qd34NKNn2LxGHDJyGdoSAJNL0P/hWwWV6z7CPff9ySuHdyF5m2AP5Ex0+dupU0u/o2HxmGC1pi6lovt/ZLTOtgHb5hxw/IYxVA2J0U14ybqtHV6ABxnf/hOp5KrRSpj/FJEKjUX3d9wHSOimGSJZMZDkgTaLbMRSZJgKI1Z9PalAnQjla+7ikNzIRLrUjm1YYnExsz0AWB7DlT7Ujqkr3UoKknuP5eoBKHh9IOhuIqWTUD7aA6huIr2RJb5ew0q2kZzWLIV4DcDAf3uybPELS+tynVDKXfXgdkwp9OGhotFUtwskpNLZKmvgEjljD9fRDJOcDp4d9oXI21snrYOFsl1PSWIZJzsbu1LWdNSFslwbZ3aexHJ0TOQpB7aInnpkG5hk/OaAQ6MZu4JJkg2JLu8G1dlCckErfHM7xeu/+QrXvPbNkzfXPoBsQ8rKknjpoJRfrZTXzYdPSeLVMb480Ukww00YwTdIjjticVtYdw1I2Cn56CTDV5EoscSBKHOCN6ptSrGoWYQhSUS/Zlub4zPxq90natFYp6DGQPRMZKHDtFun5OVrBr81vT1gVH1g+A8kcmfIGrby+lV3Np3zyo1t2PaMhzuMjI+hmth1JlZLN1dYTM/neFwF2XWFdYFmAuRyhl/Xl07XXYjC8gQJEXtj4Vgxt4ZKXDKPUvqCtely+JNJCPjV3xTY9whcWE+J6cTXie/uUe6JVDM8agDkd0LLyIZ9RYdoSwSuzZah1hrxbqrc0bzlplQMEEScyZSTH27PUGumut6BEGoY+8gaBhBuFPGyeg750CyxNpO1vg03Obx2h9jb+jvlglCh9t+ecGYx62f01yl1u/1XCtBqblL6dDJw9p3z/LH0ssDsrYhwP5PxjxKQCbEHyOv+2PqHew9UQ01/Fmj6cWZpf54+nuBEfJEQCZyUFa3B0bIGwFZ2xmU1VeDMtkUGCG/D8SP39PyArmS69t55ulecw011FBDDTXUUEMNNdRQQw011HDy8X+FjjK76Ig6MwAAAABJRU5ErkJggg==" alt="Next AutoIndex"/></div>
		<div class='ttl'>Installation Wizard</div>
<?php
if($_POST){

$fp = fopen('inc/settings.php','w');

$content = '
<?php
/*
Project Name: Next Auto Index
Project URI: http://wapindex.mirazmac.info
Project Version: 1.0
Licence: GPL v3
*/
## This is a modified version of Master Autoindex. So all source rights goes to ionutvmi ##

$set->db_name = "'.$_POST['name'].'";
$set->db_user = "'.$_POST['user'].'";
$set->db_host = "'.$_POST['host'].'";
$set->db_pass = "'.$_POST['pass'].'";


$set->name = "'.$_POST['site_name'].'"; // site name
$set->url = "'.$_POST['site_url'].'"; // site url
$set->logo = "'.$_POST['site_logo'].'"; // logo url (full url http://site.com/logo.png)
$set->perpage = "10"; // how many records per page
define("MAI_PREFIX","'.$_POST['prefix'].'");
';

if(!fwrite($fp,trim($content)))
	$error = 1;

fclose($fp);

include "inc/settings.php";

include "lib/mysql.class.php";

$db = new dbConn($set->db_host,$set->db_user,$set->db_pass,$set->db_name);


if(!$db->query("CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `path` text NOT NULL,
  `indir` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL,
  `dcount` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `icon` text NOT NULL,
  `description` text NOT NULL,
  `isdir` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;
if(!$db->query("INSERT INTO `".$_POST['prefix']."files` (`id`, `name`, `path`, `indir`, `views`, `dcount`, `time`, `size`, `icon`,`isdir`) VALUES
(1, 'Games', '/files/Games', 0, 0, 0, 1348259936, 0, '', 1);"))	$error = 1;
if(!$db->query("CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."plugins_settings` (
  `name` varchar(200) NOT NULL,
  `value` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `type` text NOT NULL,
  `plugin` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;"))	$error = 1;
if(!$db->query("CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `reply` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;
if(!$db->query("CREATE TABLE IF NOT EXISTS `".$_POST['prefix']."settings` (
  `admin_pass` varchar(100) NOT NULL,
  `main_msg` text NOT NULL,
  `active_plugins` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;"))	$error = 1;
if(!$db->query("INSERT INTO `".$_POST['prefix']."settings` (`admin_pass`, `main_msg`, `active_plugins`) VALUES
('".sha1(trim($_POST['admin_pass']))."', 'Welcome to our site !\r\nHope you enjoy it :D', 'a:0:{}');"))	$error = 1;

if($error){
echo "Fatal Error!<br/> Check if <b>/inc/settings.php</b> is writable and if your prefix is correct.";
}else {
echo "<div class='l' style='font-size: 15px;font-weight: bold;padding: 8px;color: #28B8F7;'>Installation Completed!</div>
<div class='l'>Installation completed successfully. Your site is ready to use now. <br/><span style='color:red'>Please delete this file right now!</span></div>";

// @unlink(__FILE__);
}

}else{

@chmod("files",0777);
@chmod("inc/settings.php",0666);

echo "<form action='?' method='post'>
<div class='l'>
Database Host<br/><input type='text' name='host' value='localhost'></div>
<div class='l'>
Database User<br/><input type='text' name='user'></div>
<div class='l'>
Database Password<br/><input type='text' name='pass'></div>
<div class='l'>
Database Name<br/><input type='text' name='name'></div>
<div class='l'>
Table Prefix: <br/><input type='text' name='prefix' value='nxt_'></div>
<div class='ttl'>Site Setup</div><div class='l'>
Site Title<br/><input type='text' name='site_name' value='Next AutoIndex'></div>
<div class='l'>
Site Logo URL(keep blank if you don't have)<br/><input type='text' name='site_logo'></div>
<div class='l'>
Site URL<br/><input type='text' name='site_url' value='http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."'></div>
<div class='l'>
Admin Pass: <br/><input type='text' name='admin_pass' value='12345'></div>
<br/><input type='submit' value='Run the Install!'>
</form>";

}
?>
<div id='foot'>Next AutoIndex - Reborn of MasterAuto Index</div>
	</body>
</html>