<?php
// Video WaterMark Thumb plugin
// master autoindex
// author: Sohel (masterloft.net)
// Site: http://masterloft.net
error_reporting(0);
header('Content-type: image/gif');
header('Cache-Control: public');
header('Pragma: cache');
$font = 'masterloft.ttf';
$sitename = 'NextAutoIndex'; //chage sitename
$W = 55;
$H = 55;
$file = substr(base64_decode($_GET["s"]),1);
$pic = urldecode($file[0]);
$media = new ffmpeg_movie($file);
$k_frame=intval($media->getFrameCount());
$wn=$media->GetFrameWidth();
$hn=$media->GetFrameHeight();
$frame = $media->getFrame(30);
if ($frame)
{
$gd = $frame->toGDImage();
$new = imageCreateTrueColor($W, $H);
imageCopyResized($new, $gd, 0, 0, 0, 0, $W, $H, $wn, $hn);
$bar = imageCreateTrueColor(10, 53);
imageCopyResized($new, $bar, 44, 1, 0, 0, 10, 53, $W, $H);
$TextColor = imagecolorallocate($new, 255, 255, 255);
ImageTTFtext($new, 10, 90, 52, 52, $TextColor, $font, $sitename);
imageGif($new,null,100);
}
?>
